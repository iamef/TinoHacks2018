package com.journaldev.expandablelistview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> clothing = new ArrayList<String>();
        clothing.add("Women's clothing");
        clothing.add("Men's clothing");
        clothing.add("Children's clothing");
        clothing.add("Unisex clothing");
        clothing.add("Outerwear");

        List<String> appliances = new ArrayList<String>();
        appliances.add("Toaster");
        appliances.add("Refrigerator");
        appliances.add("Microwave");
        appliances.add("Washing Machine");
        appliances.add("Other");

        List<String> tech = new ArrayList<String>();
        tech.add("Mobile Phones");
        tech.add("PC");
        tech.add("Laptops");
        tech.add("Tablets");
        tech.add("Smart Watches");

        List<String> furniture = new ArrayList<String>();
        furniture.add("Couches");
        furniture.add("Tables");
        furniture.add("Stools");
        furniture.add("Bedside Tables");
        furniture.add("Bookshelves");

        expandableListDetail.put("CLOTHING", clothing);
        expandableListDetail.put("HOUSEHOLD APPLIANCES", appliances);
        expandableListDetail.put("ELECTRONICS", tech);
        expandableListDetail.put("SECONDHAND FURNITURE", furniture);
        return expandableListDetail;
    }
}