
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump2 {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> charity = new ArrayList<String>();
        charity.add("A");
        charity.add("B");
        charity.add("C");
        charity.add("D");

        List<String> store = new ArrayList<String>();
        store.add("Goodwill");
        store.add("Asad");
        store.add("Baksdsad");
        store.add("WASdASD");
        store.add("Othasd");

        List<String> other = new ArrayList<String>();
        other.add("Upload product");

        expandableListDetail.put("CHARITIES/ORGANIZATIONS", charity);
        expandableListDetail.put("HOUSEHOLD APPLIANCES", store);
        expandableListDetail.put("SELL TO OTHER BELEAF USERS", other);
        return expandableListDetail;
    }
}