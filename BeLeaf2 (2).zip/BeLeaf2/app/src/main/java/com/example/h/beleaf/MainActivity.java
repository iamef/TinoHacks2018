package com.example.h.beleaf;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent intent = getIntent();

    }

    public void browseCategories(View view){
        Intent intent = new Intent(this, BrowseActivity.class);
        startActivity(intent);
    }

    public void sellDonate(View view){
        Intent intent = new Intent(this, SellDonateActivity.class);
        startActivity(intent);
    }

    public void signUpLogin(View view){
        Intent intent = new Intent(this, SignupLoginActivity.class);
        startActivity(intent);
    }
}
